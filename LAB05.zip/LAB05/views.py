from flask import render_template

#a funcao index recorrer ao render_template para executar o codigo html do template com o mesmo nome da funcao (index.html)
#aceita igualmente como argumento uma variavel error, que e depois passada ao template para poder ser utilizada no codigo
def index(error=None):
    return render_template('index.html', error=error)


#a semelhanca do funcao acima, a funcao executa tb um template (home.html) que recebe como argumento uma variavel username, que asusume o valor que for passado pelo 
#utilizador ao servidor
def home(username):
    return render_template('home.html', username=username)