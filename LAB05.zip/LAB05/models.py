import sqlite3

##a funcao init_db, sempre que e chamada nos controllers, cria uma nova tabela na bd users.db com o nome users, com dois campos (username e password)
##se a tabela ja existir, nenhuma parte do codigo e executada

def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users (username text PRIMARY KEY, password text)''')
    conn.commit()
    conn.close()

##a funcao add_user insere novas linhas na tabela users, sempre com um par de valores
def add_user(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("INSERT INTO users VALUES (?,?)", (username, password))
    conn.commit()
    conn.close()

##a funcao get_user foi criada com o objetivo de ir buscar a tabela users um utilizador com um username identico ao que foi passado para o servidor
def get_user(username):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    return user