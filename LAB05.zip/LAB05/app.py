from flask import Flask
import controllers, models

app = Flask(__name__)
#a existencia de uma chave secreta permite que a informacao que e carregada e armazenada no servidor permaneca
#entre pedidos por parte do mesmo user, sem correr riscos de ser modificada ou ate danificada por alguem externo ao contexto
app.secret_key = 'secret_key'

#register_blueprint associa os routes, as views e os templates que foram gerados no ficheiro controllers.py
#ao esquema de routes da aplicacao principal (app.py)
#com esta associacao, a aplicacao web fica pronta a lidar com pedidos de HTTP que lhe cheguem e a devolver as devidas respostas
app.register_blueprint(controllers.app)

if __name__ == '__main__':
    #a base de dados da aplicacao web e iniciada
    models.init_db()
    #a aplicacao e executada com recurso ao argumento debug ativo, que fornece uma lista detalhada de mensagens de erro e de apoio ao processo de testes
    app.run(debug=True)


