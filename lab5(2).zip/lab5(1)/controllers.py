from flask import Blueprint, request, redirect, url_for, session
import views
import models

#Blueprint com o nome app criado, para ser identificado depois no ficheiro app.py para integrar a aplicacao principal
app = Blueprint('app', __name__)

#se o utilizador ja estiver loggado na sessao, e redirecionado para a funcao home_controller
#caso contrario, e mostrado o conteudo da funcao index() disponivel no modulos das views
@app.route('/')
def index_controller():
    if 'username' in session:
        return redirect(url_for('app.home_controller'))
    return views.index()

#a funcao home_controller define que se o metodo passado ao servidor for do tipo POST, entao o username do proprio e eliminado da sessao atual (logout)
#e e devolvida a info presente na funcao index_controller
#se por outro lado o metodo passado for do tipo GET, a funcao devolve o resultado de uma outra funcao (views.home), no modulo das views, tendo como argumento
#o valor da variavel username

@app.route('/home', methods=['GET', 'POST'])
def home_controller():
    if request.method == 'POST':
        session.pop('username', None)
        return redirect(url_for('app.index_controller'))
    return views.home(session['username'])

#se o metodo passado ao servidor for do tipo GET

@app.route('/login', methods=['GET', 'POST'])
def login_controller():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = models.get_user(username)
        if user is not None and user[1] == password:
            session['username'] = username
            return redirect(url_for('app.home_controller'))
        return views.index(error='Incorrect username or password')
    return redirect(url_for('app.index_controller'))

@app.route('/register', methods=['GET', 'POST'])
def register_controller():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = models.get_user(username)
        if user is None:
            models.add_user(username, password)
            return redirect(url_for('app.index_controller'))
        return views.index(error='Username already taken')
    return redirect(url_for('app.index_controller'))

